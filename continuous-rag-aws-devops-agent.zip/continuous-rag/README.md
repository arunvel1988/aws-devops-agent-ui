# Continuous RAG + MCP + AWS DevOps Agent

This project creates a continuously updated company-knowledge RAG system.

## Architecture

Documents -> watcher -> parser -> chunks -> embeddings -> Qdrant

AWS DevOps Agent -> MCP -> search_company_knowledge -> Qdrant -> relevant chunks

The Bedrock/AWS agent remains responsible for reasoning and response generation.
This service supplies retrieved knowledge.

## Start

```bash
docker compose up -d --build
```

Watch logs:

```bash
docker compose logs -f rag-api
```

Check health:

```bash
curl http://localhost:8000/health
```

List indexed documents:

```bash
curl http://localhost:8000/documents
```

Test RAG:

```bash
curl -s http://localhost:8000/query \
  -H 'Content-Type: application/json' \
  -d '{"question":"What should I do when CPU is high on an EC2 instance?","top_k":5}'
```

## Continuous ingestion

Copy or edit documents under:

```text
./documents/
```

Supported:

- PDF
- DOCX
- TXT
- Markdown

The watcher automatically re-indexes changed files and removes deleted files from Qdrant.

## MCP

The MCP server exposes:

- `search_company_knowledge`
- `list_company_documents`

The Streamable HTTP endpoint is:

```text
http://YOUR_HOST:8080/mcp
```

For a remote AWS DevOps Agent connection, expose this endpoint through a secure HTTPS endpoint. Do not expose the raw development port to the public Internet without authentication/TLS.

## Important design point

The LLM is not retrained when a document changes.

Instead:

new document
-> embedding
-> vector database
-> retrieval
-> context
-> LLM

Therefore the next question can use the newly indexed information.

## Production improvements

Before production, add:

- HTTPS/TLS
- authentication/authorization
- document-level access control
- metadata filters
- hybrid keyword + vector search
- reranking
- object storage such as S3
- persistent ingestion state
- observability
- audit logging
- embedding/model versioning
- chunk deletion by document ID rather than filename
